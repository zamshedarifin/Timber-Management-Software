-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 24, 2018 at 12:37 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `atkotest`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(10) UNSIGNED NOT NULL,
  `customer_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_alt_phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `customer_name`, `customer_phone`, `customer_alt_phone`, `customer_address`, `updated_at`, `created_at`) VALUES
(1, '4234', '45345', '43534', '534', '2018-10-23 20:00:36', '2018-10-23 14:00:36'),
(2, 'erwe', 'erewr', 'ewrwer', 'ewr', '2018-10-23 20:00:43', '2018-10-23 14:00:43'),
(3, '4234', 'erewr', '43534', '32423', '2018-10-23 20:03:00', '2018-10-23 14:03:00'),
(4, '4534', '43534', '5345', '34534', '2018-10-23 20:09:34', '2018-10-23 14:09:34'),
(5, 'ripon', '324324', '343', '434', '2018-10-23 20:22:48', '2018-10-23 14:22:48');

-- --------------------------------------------------------

--
-- Table structure for table `lots`
--

CREATE TABLE `lots` (
  `id` int(10) UNSIGNED NOT NULL,
  `lot_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tree_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `second` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `third` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fourth` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `five` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `six` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seven` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `extra` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lots`
--

INSERT INTO `lots` (`id`, `lot_number`, `supplier`, `date`, `tree_name`, `position`, `first`, `second`, `third`, `fourth`, `five`, `six`, `seven`, `extra`, `created_at`, `updated_at`) VALUES
(1, 'a12', 'arafat', '2018-09-17', 'Shagun', 'Round', '23', '33', '33', '33', '3', '3', '3', NULL, NULL, NULL),
(2, 'rtrt', 'arafat', '10/04/2018', 'Shagun', 'Round', '45', '45', '54', '54433', '35', '565', '565', NULL, NULL, NULL),
(3, 'rte', 'arafat', '10/08/2018', 'Shagun', 'Square', '5656', '654654', '64564', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, '43', 'Arafat', '10/17/2018', 'Shagun', 'Round', '454', '4', '6', '7', '7', '7', '7', NULL, NULL, NULL),
(5, '43', 'Arafat', '10/17/2018', 'Mehaguni', 'Round', '343', '3', '434', '34', '343', '43', '434', NULL, NULL, NULL),
(6, '43', 'Arafat', '10/17/2018', 'Korai', 'Round', '34', '43', '434', '43', '343', '34', '34', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(62, '2014_10_12_000000_create_users_table', 1),
(63, '2014_10_12_100000_create_password_resets_table', 1),
(64, '2018_10_12_165949_create_customers_table', 1),
(65, '2018_10_12_174123_create_posts_table', 1),
(66, '2018_10_19_164539_create_lots_table', 1),
(67, '2018_10_20_221616_create_onlylots_table', 1),
(68, '2018_10_23_191656_create_suppliers_table', 1),
(69, '2018_10_23_202740_create_prices_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `onlylots`
--

CREATE TABLE `onlylots` (
  `id` int(10) UNSIGNED NOT NULL,
  `lot_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `onlylots`
--

INSERT INTO `onlylots` (`id`, `lot_number`, `supplier`, `date`, `created_at`, `updated_at`) VALUES
(1, 'a12', 'arafat', '2018-09-17', '2018-10-23 13:32:27', '2018-10-23 13:32:27'),
(2, 'rtrt', 'arafat', '10/04/2018', '2018-10-23 13:44:42', '2018-10-23 13:44:42'),
(3, 'rte', 'arafat', '10/08/2018', '2018-10-23 14:22:18', '2018-10-23 14:22:18'),
(4, '43', 'Arafat', '10/17/2018', '2018-10-23 15:27:53', '2018-10-23 15:27:53');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `cus_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pro_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qty` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `prices`
--

CREATE TABLE `prices` (
  `id` int(10) UNSIGNED NOT NULL,
  `lot_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tree_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cft` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `prices`
--

INSERT INTO `prices` (`id`, `lot_number`, `tree_name`, `position`, `product_id`, `cft`, `price`, `created_at`, `updated_at`) VALUES
(1, 'rte', 'Shagun', 'Square', 'rte', '272.94', '421364476.73', '2018-10-23 14:39:26', '2018-10-23 14:39:26'),
(2, 'rtrt', 'Shagun', 'Round', 'rtrt 44', '0.92', '41.33', '2018-10-23 14:39:50', '2018-10-23 14:39:50'),
(3, 'rtrt', 'Shagun', 'Round', 'rtrt', '21.57', '2356901.58', '2018-10-23 14:42:27', '2018-10-23 14:42:27'),
(4, 'a12', 'Shagun', 'Round', 'a12', '204.25', '612.76', '2018-10-23 15:15:06', '2018-10-23 15:15:06'),
(5, 'a12', 'Shagun', 'Round', 'a12', '0.69', '22.73', '2018-10-23 15:20:43', '2018-10-23 15:20:43'),
(6, 'rtrt', 'Shagun', 'Round', 'rtrt', '0.92', '41.33', '2018-10-23 15:24:37', '2018-10-23 15:24:37'),
(7, '43', 'Korai', 'Round', '43', '2.01', '173.20', '2018-10-23 15:28:09', '2018-10-23 15:28:09');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` int(10) UNSIGNED NOT NULL,
  `supplier_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supplier_phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supplier_alt_phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supplier_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `supplier_name`, `supplier_phone`, `supplier_alt_phone`, `supplier_address`, `created_at`, `updated_at`) VALUES
(1, 'arafat', '12312', '314321', '214', '2018-10-23 13:31:47', '2018-10-23 13:31:47'),
(2, 'Arafat', '4543', '3454', '534', '2018-10-23 13:44:24', '2018-10-23 13:44:24'),
(3, 'Arafat', '4543', '3454', '534', '2018-10-23 14:07:52', '2018-10-23 14:07:52'),
(4, 'Arafat', '4543', '3454', '534', '2018-10-23 14:08:15', '2018-10-23 14:08:15');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lots`
--
ALTER TABLE `lots`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `onlylots`
--
ALTER TABLE `onlylots`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prices`
--
ALTER TABLE `prices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `lots`
--
ALTER TABLE `lots`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `onlylots`
--
ALTER TABLE `onlylots`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `prices`
--
ALTER TABLE `prices`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
